import React, { createContext, useContext, useState, ReactNode } from 'react';

// Mock data types
interface CivicProfile {
  id: string;
  name: string;
  role: string;
  location: string;
  civicScore: number;
  totalReports: number;
  positiveReports: number;
  trend: 'up' | 'down' | 'stable';
}

interface Report {
  id: string;
  profileId?: string;
  type: 'positive' | 'negative' | 'neutral';
  description: string;
  location: string;
  date: string;
}

interface CivicDataContextType {
  civicProfiles: CivicProfile[];
  recentReports: Report[];
  addReport: (report: Omit<Report, 'id'>) => void;
  updateProfile: (profileId: string, updates: Partial<CivicProfile>) => void;
}

const CivicDataContext = createContext<CivicDataContextType | undefined>(undefined);

// Mock data
const mockProfiles: CivicProfile[] = [
  {
    id: '1',
    name: 'Inspector Kumar',
    role: 'Police Officer',
    location: 'Mumbai',
    civicScore: 987,
    totalReports: 156,
    positiveReports: 142,
    trend: 'up',
  },
  {
    id: '2',
    name: 'Dr. Priya Sharma',
    role: 'Government Doctor',
    location: 'Delhi',
    civicScore: 954,
    totalReports: 89,
    positiveReports: 81,
    trend: 'up',
  },
  {
    id: '3',
    name: 'Officer Raj',
    role: 'Traffic Police',
    location: 'Bangalore',
    civicScore: 941,
    totalReports: 203,
    positiveReports: 187,
    trend: 'stable',
  },
  {
    id: '4',
    name: 'Ms. Anjali',
    role: 'Municipal Officer',
    location: 'Chennai',
    civicScore: 928,
    totalReports: 67,
    positiveReports: 59,
    trend: 'up',
  },
  {
    id: '5',
    name: 'Prof. Mehta',
    role: 'Teacher',
    location: 'Pune',
    civicScore: 915,
    totalReports: 45,
    positiveReports: 41,
    trend: 'stable',
  },
  {
    id: '6',
    name: 'Constable Singh',
    role: 'Police Officer',
    location: 'Mumbai',
    civicScore: 723,
    totalReports: 78,
    positiveReports: 52,
    trend: 'down',
  },
  {
    id: '7',
    name: 'Dr. Reddy',
    role: 'Hospital Staff',
    location: 'Hyderabad',
    civicScore: 856,
    totalReports: 134,
    positiveReports: 118,
    trend: 'up',
  },
  {
    id: '8',
    name: 'Mr. Gupta',
    role: 'Bank Employee',
    location: 'Delhi',
    civicScore: 692,
    totalReports: 56,
    positiveReports: 34,
    trend: 'down',
  },
  {
    id: '9',
    name: 'Inspector Patel',
    role: 'Police Officer',
    location: 'Ahmedabad',
    civicScore: 834,
    totalReports: 91,
    positiveReports: 76,
    trend: 'stable',
  },
  {
    id: '10',
    name: 'Ms. Joshi',
    role: 'Government Official',
    location: 'Pune',
    civicScore: 567,
    totalReports: 43,
    positiveReports: 21,
    trend: 'down',
  },
];

const mockReports: Report[] = [
  {
    id: '1',
    profileId: '1',
    type: 'positive',
    description: 'Officer Kumar helped resolve a traffic dispute quickly and professionally',
    location: 'Bandra, Mumbai',
    date: '2025-01-15',
  },
  {
    id: '2',
    profileId: '2',
    type: 'positive',
    description: 'Dr. Sharma provided excellent care during emergency situation',
    location: 'AIIMS, Delhi',
    date: '2025-01-14',
  },
  {
    id: '3',
    profileId: '6',
    type: 'negative',
    description: 'Unprofessional behavior and delayed response to complaint',
    location: 'Andheri, Mumbai',
    date: '2025-01-13',
  },
  {
    id: '4',
    profileId: '3',
    type: 'positive',
    description: 'Efficient traffic management during peak hours',
    location: 'MG Road, Bangalore',
    date: '2025-01-12',
  },
  {
    id: '5',
    profileId: '8',
    type: 'negative',
    description: 'Long waiting times and poor customer service',
    location: 'Connaught Place, Delhi',
    date: '2025-01-11',
  },
  {
    id: '6',
    profileId: '4',
    type: 'positive',
    description: 'Quick resolution of municipal complaint',
    location: 'T. Nagar, Chennai',
    date: '2025-01-10',
  },
  {
    id: '7',
    type: 'neutral',
    description: 'Road maintenance work completed on schedule',
    location: 'Koramangala, Bangalore',
    date: '2025-01-09',
  },
  {
    id: '8',
    profileId: '7',
    type: 'positive',
    description: 'Compassionate care and clear communication with patients',
    location: 'Apollo Hospital, Hyderabad',
    date: '2025-01-08',
  },
];

export const CivicDataProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [civicProfiles, setCivicProfiles] = useState<CivicProfile[]>(mockProfiles);
  const [recentReports, setRecentReports] = useState<Report[]>(mockReports);

  const addReport = (report: Omit<Report, 'id'>) => {
    const newReport: Report = {
      ...report,
      id: Math.random().toString(36).substr(2, 9),
    };
    setRecentReports(prev => [newReport, ...prev]);
  };

  const updateProfile = (profileId: string, updates: Partial<CivicProfile>) => {
    setCivicProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { ...profile, ...updates }
          : profile
      )
    );
  };

  const value: CivicDataContextType = {
    civicProfiles,
    recentReports,
    addReport,
    updateProfile,
  };

  return (
    <CivicDataContext.Provider value={value}>
      {children}
    </CivicDataContext.Provider>
  );
};

export const useCivicData = (): CivicDataContextType => {
  const context = useContext(CivicDataContext);
  if (context === undefined) {
    throw new Error('useCivicData must be used within a CivicDataProvider');
  }
  return context;
};