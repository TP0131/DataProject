import React, { useState, useEffect } from 'react';
import { Navigation } from './components/Navigation';
import { LandingPage } from './components/LandingPage';
import { Dashboard } from './components/Dashboard';
import { ReportForm } from './components/ReportForm';
import { SearchResults } from './components/SearchResults';
import { ProfilePage } from './components/ProfilePage';
import { WhistleblowerMode } from './components/WhistleblowerMode';
import { Analytics } from './components/Analytics';
import { AuthModal } from './components/AuthModal';
import { CivicDataProvider } from './context/CivicDataContext';

type Page = 'landing' | 'dashboard' | 'report' | 'search' | 'profile' | 'whistleblower' | 'analytics';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [selectedProfileId, setSelectedProfileId] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);

  const handleNavigate = (page: Page, profileId?: string) => {
    if ((page !== 'landing' && page !== 'search') && !isAuthenticated) {
      setShowAuthModal(true);
      return;
    }
    
    setCurrentPage(page);
    if (profileId) {
      setSelectedProfileId(profileId);
    }
  };

  const handleAuth = (success: boolean) => {
    if (success) {
      setIsAuthenticated(true);
      setShowAuthModal(false);
    }
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage onNavigate={handleNavigate} />;
      case 'dashboard':
        return <Dashboard onNavigate={handleNavigate} />;
      case 'report':
        return <ReportForm onNavigate={handleNavigate} />;
      case 'search':
        return <SearchResults onNavigate={handleNavigate} />;
      case 'profile':
        return <ProfilePage profileId={selectedProfileId} onNavigate={handleNavigate} />;
      case 'whistleblower':
        return <WhistleblowerMode onNavigate={handleNavigate} />;
      case 'analytics':
        return <Analytics onNavigate={handleNavigate} />;
      default:
        return <LandingPage onNavigate={handleNavigate} />;
    }
  };

  return (
    <CivicDataProvider>
      <div className="min-h-screen bg-gray-50">
        {currentPage !== 'landing' && (
          <Navigation 
            currentPage={currentPage} 
            onNavigate={handleNavigate}
            isAuthenticated={isAuthenticated}
            onShowAuth={() => setShowAuthModal(true)}
          />
        )}
        
        <main className={currentPage !== 'landing' ? 'pt-16' : ''}>
          {renderCurrentPage()}
        </main>

        {showAuthModal && (
          <AuthModal 
            onClose={() => setShowAuthModal(false)}
            onAuth={handleAuth}
          />
        )}
      </div>
    </CivicDataProvider>
  );
}

export default App;