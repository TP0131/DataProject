import React from 'react';
import { TrendingUp, TrendingDown, Users, FileText, Award, AlertTriangle, MapPin, Calendar, Camera, Eye } from 'lucide-react';
import { useCivicData } from '../context/CivicDataContext';

interface DashboardProps {
  onNavigate: (page: string, profileId?: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { recentReports, civicProfiles } = useCivicData();

  const stats = [
    { 
      title: 'Total Reports', 
      value: '12,847', 
      change: '+8.2%', 
      trend: 'up',
      icon: FileText,
      color: 'blue',
      image: 'https://images.pexels.com/photos/4348401/pexels-photo-4348401.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    { 
      title: 'Active Profiles', 
      value: '3,421', 
      change: '+5.1%', 
      trend: 'up',
      icon: Users,
      color: 'green',
      image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    { 
      title: 'Civic Heroes', 
      value: '127', 
      change: '+12.3%', 
      trend: 'up',
      icon: Award,
      color: 'yellow',
      image: 'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
    { 
      title: 'Urgent Cases', 
      value: '23', 
      change: '-2.1%', 
      trend: 'down',
      icon: AlertTriangle,
      color: 'red',
      image: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=300'
    },
  ];

  const topProfiles = civicProfiles
    .sort((a, b) => b.civicScore - a.civicScore)
    .slice(0, 5);

  const recentActivity = recentReports.slice(0, 6);

  const getScoreColor = (score: number) => {
    if (score >= 800) return 'text-green-600 bg-green-100';
    if (score >= 600) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 800) return 'Excellent';
    if (score >= 600) return 'Good';
    return 'Needs Improvement';
  };

  const quickActions = [
    {
      title: 'Search Profiles',
      description: 'Find and verify public servants in your area',
      color: 'from-blue-500 to-blue-600',
      hoverColor: 'hover:from-blue-600 hover:to-blue-700',
      page: 'search',
      image: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400',
      icon: Users
    },
    {
      title: 'File Report',
      description: 'Submit a new civic accountability report',
      color: 'from-green-500 to-green-600',
      hoverColor: 'hover:from-green-600 hover:to-green-700',
      page: 'report',
      image: 'https://images.pexels.com/photos/4348401/pexels-photo-4348401.jpeg?auto=compress&cs=tinysrgb&w=400',
      icon: FileText
    },
    {
      title: 'View Analytics',
      description: 'Analyze trends and patterns in your region',
      color: 'from-purple-500 to-purple-600',
      hoverColor: 'hover:from-purple-600 hover:to-purple-700',
      page: 'analytics',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
      icon: TrendingUp
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">CivicLens Dashboard</h1>
          <p className="text-gray-600">Monitor civic accountability and track public service performance</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all duration-300 group">
              <div className="relative mb-4">
                <img 
                  src={stat.image} 
                  alt={stat.title}
                  className="w-full h-24 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute top-2 right-2 p-2 bg-white/90 backdrop-blur-sm rounded-lg">
                  <stat.icon className={`h-4 w-4 ${
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'green' ? 'text-green-600' :
                    stat.color === 'yellow' ? 'text-yellow-600' : 'text-red-600'
                  }`} />
                </div>
                <div className={`absolute bottom-2 right-2 flex items-center text-xs ${
                  stat.trend === 'up' ? 'text-green-600' : 'text-red-600'
                } bg-white/90 backdrop-blur-sm rounded px-2 py-1`}>
                  {stat.trend === 'up' ? <TrendingUp className="h-3 w-3 mr-1" /> : <TrendingDown className="h-3 w-3 mr-1" />}
                  {stat.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.title}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Top Performing Profiles */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Top Civic Performers</h2>
              <Award className="h-5 w-5 text-yellow-500" />
            </div>
            <div className="space-y-4">
              {topProfiles.map((profile, index) => (
                <div 
                  key={profile.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors group"
                  onClick={() => onNavigate('profile', profile.id)}
                >
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {index + 1}
                      </div>
                      {index === 0 && (
                        <div className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-500 rounded-full flex items-center justify-center">
                          <span className="text-xs">👑</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center space-x-3">
                      <img 
                        src={`https://images.pexels.com/photos/${1000000 + index * 100000}/pexels-photo-${1000000 + index * 100000}.jpeg?auto=compress&cs=tinysrgb&w=100`}
                        alt={profile.name}
                        className="w-8 h-8 rounded-full object-cover"
                        onError={(e) => {
                          e.currentTarget.src = 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100';
                        }}
                      />
                      <div>
                        <div className="font-medium text-gray-900">{profile.name}</div>
                        <div className="text-sm text-gray-600">{profile.role} • {profile.location}</div>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${getScoreColor(profile.civicScore)}`}>
                      {profile.civicScore}
                    </div>
                    <div className="text-xs text-gray-500 mt-1">{getScoreLabel(profile.civicScore)}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Recent Activity</h2>
              <FileText className="h-5 w-5 text-blue-500" />
            </div>
            <div className="space-y-4">
              {recentActivity.map((report, index) => (
                <div key={report.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg group hover:bg-gray-100 transition-colors">
                  <div className="relative">
                    <div className={`w-3 h-3 rounded-full mt-2 ${
                      report.type === 'positive' ? 'bg-green-500' : 
                      report.type === 'negative' ? 'bg-red-500' : 'bg-yellow-500'
                    }`}></div>
                    {index < 3 && (
                      <img 
                        src={`https://images.pexels.com/photos/${2000000 + index * 50000}/pexels-photo-${2000000 + index * 50000}.jpeg?auto=compress&cs=tinysrgb&w=50`}
                        alt="Report evidence"
                        className="w-8 h-8 rounded object-cover mt-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        onError={(e) => {
                          e.currentTarget.src = 'https://images.pexels.com/photos/4348401/pexels-photo-4348401.jpeg?auto=compress&cs=tinysrgb&w=50';
                        }}
                      />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2 mb-1">
                      <div className="text-sm font-medium text-gray-900">
                        {report.type === 'positive' ? 'Positive Review' : 
                         report.type === 'negative' ? 'Complaint Filed' : 'Incident Reported'}
                      </div>
                      {index < 2 && <Camera className="h-3 w-3 text-gray-400" />}
                    </div>
                    <div className="text-sm text-gray-600 truncate">{report.description}</div>
                    <div className="flex items-center text-xs text-gray-500 mt-1">
                      <MapPin className="h-3 w-3 mr-1" />
                      {report.location}
                      <Calendar className="h-3 w-3 ml-2 mr-1" />
                      {report.date}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <button 
              onClick={() => onNavigate('report')}
              className="w-full mt-4 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium flex items-center justify-center space-x-2"
            >
              <Camera className="h-4 w-4" />
              <span>Submit New Report</span>
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {quickActions.map((action, index) => (
            <div 
              key={index}
              className={`bg-gradient-to-br ${action.color} p-6 rounded-lg text-white cursor-pointer ${action.hoverColor} transition-all duration-300 group relative overflow-hidden`}
              onClick={() => onNavigate(action.page)}
            >
              <div className="absolute inset-0 opacity-20">
                <img 
                  src={action.image} 
                  alt={action.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="relative z-10">
                <div className="flex items-center space-x-3 mb-3">
                  <action.icon className="h-6 w-6" />
                  <h3 className="text-lg font-bold">{action.title}</h3>
                </div>
                <p className="text-white/90 text-sm">{action.description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Whistleblower CTA */}
        <div className="mt-8 bg-gradient-to-r from-gray-800 to-gray-900 rounded-lg p-6 text-white relative overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <img 
              src="https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800" 
              alt="Security"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="relative z-10 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-white/10 rounded-lg">
                <Eye className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-1">Need to Report Anonymously?</h3>
                <p className="text-gray-300">Use our secure whistleblower mode for sensitive reports</p>
              </div>
            </div>
            <button
              onClick={() => onNavigate('whistleblower')}
              className="bg-white text-gray-900 px-6 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors"
            >
              Enter Secure Mode
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};