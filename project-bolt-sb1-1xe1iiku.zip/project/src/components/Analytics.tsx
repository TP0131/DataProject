import React, { useState } from 'react';
import { BarChart3, TrendingUp, TrendingDown, MapPin, Users, AlertTriangle, Award, Calendar, Filter } from 'lucide-react';

interface AnalyticsProps {
  onNavigate: (page: string) => void;
}

export const Analytics: React.FC<AnalyticsProps> = ({ onNavigate }) => {
  const [timeRange, setTimeRange] = useState('30d');
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const timeRanges = [
    { value: '7d', label: 'Last 7 Days' },
    { value: '30d', label: 'Last 30 Days' },
    { value: '90d', label: 'Last 3 Months' },
    { value: '1y', label: 'Last Year' },
  ];

  const regions = [
    { value: 'all', label: 'All Regions' },
    { value: 'mumbai', label: 'Mumbai' },
    { value: 'delhi', label: 'Delhi' },
    { value: 'bangalore', label: 'Bangalore' },
    { value: 'chennai', label: 'Chennai' },
  ];

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'police', label: 'Police' },
    { value: 'government', label: 'Government' },
    { value: 'healthcare', label: 'Healthcare' },
    { value: 'education', label: 'Education' },
  ];

  const kpis = [
    {
      title: 'Total Reports',
      value: '12,847',
      change: '+8.2%',
      trend: 'up',
      color: 'blue',
      icon: BarChart3,
    },
    {
      title: 'Avg Civic Score',
      value: '742',
      change: '+5.3%',
      trend: 'up',
      color: 'green',
      icon: TrendingUp,
    },
    {
      title: 'High-Risk Areas',
      value: '23',
      change: '-12.1%',
      trend: 'down',
      color: 'red',
      icon: AlertTriangle,
    },
    {
      title: 'Civic Heroes',
      value: '127',
      change: '+15.8%',
      trend: 'up',
      color: 'yellow',
      icon: Award,
    },
  ];

  const topPerformers = [
    { name: 'Inspector Kumar', role: 'Police Officer', location: 'Mumbai', score: 987 },
    { name: 'Dr. Priya Sharma', role: 'Government Doctor', location: 'Delhi', score: 954 },
    { name: 'Officer Raj', role: 'Traffic Police', location: 'Bangalore', score: 941 },
    { name: 'Ms. Anjali', role: 'Municipal Officer', location: 'Chennai', score: 928 },
    { name: 'Prof. Mehta', role: 'Teacher', location: 'Pune', score: 915 },
  ];

  const riskAreas = [
    { area: 'Downtown Police Station', reports: 45, risk: 'High', change: '+23%' },
    { area: 'City Hospital', reports: 32, risk: 'Medium', change: '+8%' },
    { area: 'Municipal Office Block A', reports: 28, risk: 'Medium', change: '-5%' },
    { area: 'Traffic Junction XYZ', reports: 21, risk: 'Low', change: '-12%' },
  ];

  const monthlyData = [
    { month: 'Jan', reports: 1200, score: 735 },
    { month: 'Feb', reports: 1350, score: 742 },
    { month: 'Mar', reports: 1180, score: 748 },
    { month: 'Apr', reports: 1420, score: 751 },
    { month: 'May', reports: 1280, score: 745 },
    { month: 'Jun', reports: 1380, score: 752 },
  ];

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'High': return 'text-red-600 bg-red-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Civic Analytics Dashboard</h1>
          <p className="text-gray-600">Comprehensive insights into civic accountability and performance trends</p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Filter className="h-5 w-5 text-gray-500" />
            <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Time Range</label>
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {timeRanges.map((range) => (
                  <option key={range.value} value={range.value}>{range.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Region</label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {regions.map((region) => (
                  <option key={region.value} value={region.value}>{region.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {categories.map((category) => (
                  <option key={category.value} value={category.value}>{category.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {kpis.map((kpi, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-2 rounded-lg ${
                  kpi.color === 'blue' ? 'bg-blue-100' :
                  kpi.color === 'green' ? 'bg-green-100' :
                  kpi.color === 'red' ? 'bg-red-100' : 'bg-yellow-100'
                }`}>
                  <kpi.icon className={`h-5 w-5 ${
                    kpi.color === 'blue' ? 'text-blue-600' :
                    kpi.color === 'green' ? 'text-green-600' :
                    kpi.color === 'red' ? 'text-red-600' : 'text-yellow-600'
                  }`} />
                </div>
                <div className={`flex items-center text-sm ${
                  kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'
                }`}>
                  {kpi.trend === 'up' ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                  {kpi.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{kpi.value}</div>
              <div className="text-sm text-gray-600">{kpi.title}</div>
            </div>
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Monthly Trends */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-6">Monthly Trends</h3>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Interactive chart showing monthly report trends</p>
                <p className="text-sm text-gray-500 mt-2">Reports vs Civic Score correlation</p>
              </div>
            </div>
          </div>

          {/* Regional Heatmap */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-6">Regional Performance Heatmap</h3>
            <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
              <div className="text-center">
                <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Interactive map showing performance by region</p>
                <p className="text-sm text-gray-500 mt-2">Color-coded civic score distribution</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Top Performers */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900">Top Performers</h3>
              <Award className="h-5 w-5 text-yellow-500" />
            </div>
            <div className="space-y-4">
              {topPerformers.map((performer, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{performer.name}</div>
                      <div className="text-sm text-gray-600">{performer.role} • {performer.location}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold text-green-600">{performer.score}</div>
                    <div className="text-xs text-gray-500">Civic Score</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Risk Areas */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold text-gray-900">Areas Requiring Attention</h3>
              <AlertTriangle className="h-5 w-5 text-red-500" />
            </div>
            <div className="space-y-4">
              {riskAreas.map((area, index) => (
                <div key={index} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-gray-900">{area.area}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getRiskColor(area.risk)}`}>
                      {area.risk} Risk
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">{area.reports} reports</span>
                    <span className={`font-medium ${
                      area.change.startsWith('+') ? 'text-red-600' : 'text-green-600'
                    }`}>
                      {area.change}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Export Options */}
        <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Export & Share</h3>
          <div className="flex flex-wrap gap-4">
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm">
              Export PDF Report
            </button>
            <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm">
              Download CSV Data
            </button>
            <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Generate Public Dashboard
            </button>
            <button className="border border-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-50 transition-colors text-sm">
              Schedule Email Reports
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};