import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Shield, AlertTriangle, CheckCircle, Upload, FileText } from 'lucide-react';

interface WhistleblowerModeProps {
  onNavigate: (page: string) => void;
}

export const WhistleblowerMode: React.FC<WhistleblowerModeProps> = ({ onNavigate }) => {
  const [isSecureMode, setIsSecureMode] = useState(false);
  const [formData, setFormData] = useState({
    reportType: 'corruption',
    severity: 'high',
    description: '',
    evidence: null as File | null,
    location: '',
    department: '',
    timeframe: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const reportTypes = [
    { value: 'corruption', label: 'Corruption/Bribery', icon: '💰' },
    { value: 'abuse', label: 'Abuse of Power', icon: '⚖️' },
    { value: 'harassment', label: 'Harassment', icon: '🚫' },
    { value: 'discrimination', label: 'Discrimination', icon: '🏳️' },
    { value: 'negligence', label: 'Gross Negligence', icon: '⚠️' },
    { value: 'fraud', label: 'Fraud/Embezzlement', icon: '🏦' },
    { value: 'safety', label: 'Safety Violations', icon: '🦺' },
    { value: 'other', label: 'Other Serious Violation', icon: '📋' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate secure submission
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setIsSubmitting(false);
    setSubmitted(true);
    
    // Auto-redirect after 5 seconds
    setTimeout(() => {
      onNavigate('dashboard');
    }, 5000);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center p-6">
        <div className="bg-gray-800 rounded-lg shadow-2xl p-8 max-w-md w-full text-center border border-gray-700">
          <div className="w-16 h-16 bg-green-900 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-8 w-8 text-green-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Report Submitted Securely</h2>
          <p className="text-gray-300 mb-6">
            Your anonymous report has been encrypted and submitted safely. 
            Your identity is protected and the information will be investigated appropriately.
          </p>
          <div className="space-y-3">
            <div className="bg-gray-700 p-3 rounded-lg">
              <p className="text-sm text-gray-300">
                <strong className="text-white">Secure ID:</strong> WB-{Math.random().toString(36).substr(2, 12).toUpperCase()}
              </p>
            </div>
            <div className="bg-blue-900 p-3 rounded-lg">
              <p className="text-xs text-blue-200">
                Save this ID to track your report status anonymously
              </p>
            </div>
            <button
              onClick={() => onNavigate('dashboard')}
              className="w-full bg-gray-700 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors mt-4"
            >
              Return to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Security Toggle */}
        <div className="bg-yellow-900 border border-yellow-700 rounded-lg p-4 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <AlertTriangle className="h-6 w-6 text-yellow-400" />
              <div>
                <h3 className="text-yellow-200 font-bold">Whistleblower Protection Mode</h3>
                <p className="text-yellow-300 text-sm">Enhanced security and anonymity for sensitive reports</p>
              </div>
            </div>
            <button
              onClick={() => setIsSecureMode(!isSecureMode)}
              className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                isSecureMode 
                  ? 'bg-green-700 text-green-100 hover:bg-green-600' 
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              {isSecureMode ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              <span className="text-sm">{isSecureMode ? 'Secure Mode ON' : 'Activate Secure Mode'}</span>
            </button>
          </div>
        </div>

        {/* Security Features */}
        {isSecureMode && (
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-6 mb-8">
            <h3 className="text-white font-bold mb-4 flex items-center space-x-2">
              <Shield className="h-5 w-5 text-green-400" />
              <span>Active Security Features</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-gray-300">End-to-end encryption</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-gray-300">Anonymous submission</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-gray-300">Identity protection</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span className="text-gray-300">Secure evidence storage</span>
              </div>
            </div>
          </div>
        )}

        {/* Main Form */}
        <div className="bg-gray-800 rounded-lg shadow-2xl border border-gray-700 p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Anonymous Whistleblower Report</h1>
            <p className="text-gray-300">Report serious violations with complete anonymity and protection</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {/* Report Type */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-4">Type of Violation</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {reportTypes.map((type) => (
                  <label key={type.value} className="cursor-pointer">
                    <input
                      type="radio"
                      name="reportType"
                      value={type.value}
                      checked={formData.reportType === type.value}
                      onChange={(e) => setFormData(prev => ({ ...prev, reportType: e.target.value }))}
                      className="sr-only"
                    />
                    <div className={`p-4 border-2 rounded-lg transition-all ${
                      formData.reportType === type.value 
                        ? 'border-red-500 bg-red-900/20' 
                        : 'border-gray-600 hover:border-gray-500 bg-gray-700/50'
                    }`}>
                      <div className="flex items-center space-x-3">
                        <span className="text-xl">{type.icon}</span>
                        <span className="text-gray-200 font-medium">{type.label}</span>
                      </div>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Severity */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-3">Severity Level</label>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { value: 'low', label: 'Low', color: 'yellow' },
                  { value: 'medium', label: 'Medium', color: 'orange' },
                  { value: 'high', label: 'High', color: 'red' },
                ].map((severity) => (
                  <label key={severity.value} className="cursor-pointer">
                    <input
                      type="radio"
                      name="severity"
                      value={severity.value}
                      checked={formData.severity === severity.value}
                      onChange={(e) => setFormData(prev => ({ ...prev, severity: e.target.value }))}
                      className="sr-only"
                    />
                    <div className={`p-3 text-center border-2 rounded-lg transition-all ${
                      formData.severity === severity.value 
                        ? `border-${severity.color}-500 bg-${severity.color}-900/20 text-${severity.color}-200` 
                        : 'border-gray-600 hover:border-gray-500 bg-gray-700/50 text-gray-300'
                    }`}>
                      {severity.label}
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-200 mb-2">
                  Department/Organization
                </label>
                <input
                  type="text"
                  value={formData.department}
                  onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
                  placeholder="e.g., Police Department, Municipal Office"
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-200 mb-2">
                  General Location
                </label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  placeholder="e.g., City/District (keep general for safety)"
                  className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
                />
              </div>
            </div>

            {/* Timeframe */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-2">
                When did this occur?
              </label>
              <input
                type="text"
                value={formData.timeframe}
                onChange={(e) => setFormData(prev => ({ ...prev, timeframe: e.target.value }))}
                placeholder="e.g., Last week, December 2024, Ongoing"
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-2">
                Detailed Description *
              </label>
              <textarea
                required
                rows={6}
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Provide a detailed account of the violation. Include facts, dates, and any relevant context. Avoid including information that could identify you."
                className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-white placeholder-gray-400"
              />
            </div>

            {/* Evidence Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-200 mb-2">
                Secure Evidence Upload
              </label>
              <div className="mt-2 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-600 border-dashed rounded-lg hover:border-gray-500 transition-colors">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="flex text-sm text-gray-300">
                    <label className="relative cursor-pointer bg-gray-700 rounded-md font-medium text-blue-400 hover:text-blue-300 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500 px-2 py-1">
                      <span>Upload encrypted file</span>
                      <input
                        type="file"
                        className="sr-only"
                        accept="image/*,video/*,audio/*,.pdf,.doc,.docx"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setFormData(prev => ({ ...prev, evidence: file }));
                          }
                        }}
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-400">
                    Files are automatically encrypted for your protection
                  </p>
                  {formData.evidence && (
                    <div className="mt-2 text-sm text-green-400">
                      Encrypted file: {formData.evidence.name}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Privacy Notice */}
            <div className="bg-blue-900/20 border border-blue-700 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <Lock className="h-5 w-5 text-blue-400 mt-0.5" />
                <div>
                  <h4 className="text-blue-200 font-medium mb-2">Privacy & Protection Guarantee</h4>
                  <ul className="text-blue-300 text-sm space-y-1">
                    <li>• Your identity will never be revealed</li>
                    <li>• All data is encrypted end-to-end</li>
                    <li>• Evidence is stored in secure, tamper-proof systems</li>
                    <li>• You can track your report status anonymously</li>
                    <li>• Legal protections apply to your submission</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="flex space-x-4">
              <button
                type="submit"
                disabled={isSubmitting || !isSecureMode}
                className="flex-1 bg-red-600 text-white py-3 px-6 rounded-lg hover:bg-red-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Submitting Securely...</span>
                  </>
                ) : (
                  <>
                    <Shield className="h-4 w-4" />
                    <span>Submit Anonymous Report</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={() => onNavigate('dashboard')}
                className="px-6 py-3 border border-gray-600 text-gray-300 rounded-lg hover:bg-gray-700 transition-colors"
              >
                Cancel
              </button>
            </div>

            {!isSecureMode && (
              <div className="text-center text-yellow-300 text-sm">
                ⚠️ Please activate Secure Mode above before submitting your report
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
};