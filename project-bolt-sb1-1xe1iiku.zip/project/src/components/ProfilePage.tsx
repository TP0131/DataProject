import React, { useState } from 'react';
import { User, MapPin, Calendar, TrendingUp, TrendingDown, Star, AlertTriangle, Award, FileText, Shield, ArrowLeft } from 'lucide-react';
import { useCivicData } from '../context/CivicDataContext';

interface ProfilePageProps {
  profileId: string | null;
  onNavigate: (page: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ profileId, onNavigate }) => {
  const { civicProfiles, recentReports } = useCivicData();
  const [activeTab, setActiveTab] = useState('overview');

  const profile = civicProfiles.find(p => p.id === profileId);
  const profileReports = recentReports.filter(r => r.profileId === profileId);

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Profile Not Found</h2>
          <p className="text-gray-600 mb-4">The requested profile could not be found.</p>
          <button
            onClick={() => onNavigate('search')}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Search
          </button>
        </div>
      </div>
    );
  }

  const getScoreColor = (score: number) => {
    if (score >= 800) return 'text-green-600 bg-green-100';
    if (score >= 600) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 800) return 'Excellent';
    if (score >= 600) return 'Good';
    return 'Needs Improvement';
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: User },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'trends', label: 'Trends', icon: TrendingUp },
    { id: 'verification', label: 'Verification', icon: Shield },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Back Button */}
        <button
          onClick={() => onNavigate('search')}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 mb-6 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Search</span>
        </button>

        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
            <div className="flex items-center space-x-6 mb-6 md:mb-0">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <User className="h-10 w-10 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{profile.name}</h1>
                <p className="text-lg text-gray-600 mb-2">{profile.role}</p>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <MapPin className="h-4 w-4" />
                    <span>{profile.location}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>Since Jan 2020</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="text-center">
              <div className={`inline-flex items-center px-4 py-2 rounded-full text-2xl font-bold ${getScoreColor(profile.civicScore)}`}>
                {profile.civicScore}
              </div>
              <div className="text-sm text-gray-600 mt-1">{getScoreLabel(profile.civicScore)}</div>
              <div className="flex items-center justify-center mt-2">
                {profile.trend === 'up' ? (
                  <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                ) : profile.trend === 'down' ? (
                  <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                ) : (
                  <div className="h-4 w-4 rounded-full bg-gray-400 mr-1"></div>
                )}
                <span className="text-sm text-gray-600">
                  {profile.trend === 'up' ? 'Improving' : profile.trend === 'down' ? 'Declining' : 'Stable'}
                </span>
              </div>
            </div>
          </div>

          {/* Key Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-8 pt-8 border-t border-gray-200">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">{profile.totalReports}</div>
              <div className="text-sm text-gray-600">Total Reports</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{profile.positiveReports}</div>
              <div className="text-sm text-gray-600">Positive Reviews</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{profile.totalReports - profile.positiveReports}</div>
              <div className="text-sm text-gray-600">Complaints</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {profile.civicScore >= 800 ? '🏆' : profile.civicScore >= 600 ? '⭐' : '📊'}
              </div>
              <div className="text-sm text-gray-600">
                {profile.civicScore >= 800 ? 'Civic Hero' : profile.civicScore >= 600 ? 'Good Standing' : 'Monitoring'}
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          <div className="p-6">
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h3 className="font-bold text-gray-900 mb-4">Civic Score Breakdown</h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Professional Conduct</span>
                        <span className="font-medium">85%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Response Time</span>
                        <span className="font-medium">78%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Helpfulness</span>
                        <span className="font-medium">92%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Integrity</span>
                        <span className="font-medium">88%</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-green-50 p-6 rounded-lg">
                    <h3 className="font-bold text-gray-900 mb-4">Recent Achievements</h3>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-3">
                        <Award className="h-5 w-5 text-yellow-500" />
                        <span className="text-gray-700">100+ Positive Reviews</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Star className="h-5 w-5 text-blue-500" />
                        <span className="text-gray-700">Top Performer in Region</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Shield className="h-5 w-5 text-green-500" />
                        <span className="text-gray-700">No Serious Complaints</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'reports' && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-bold text-gray-900">Recent Reports</h3>
                  <button
                    onClick={() => onNavigate('report')}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    Add Report
                  </button>
                </div>
                
                {profileReports.length > 0 ? (
                  <div className="space-y-4">
                    {profileReports.map((report) => (
                      <div key={report.id} className="bg-gray-50 p-4 rounded-lg border">
                        <div className="flex items-start space-x-3">
                          <div className={`w-3 h-3 rounded-full mt-1 ${
                            report.type === 'positive' ? 'bg-green-500' : 
                            report.type === 'negative' ? 'bg-red-500' : 'bg-yellow-500'
                          }`}></div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium text-gray-900">
                                {report.type === 'positive' ? 'Positive Review' : 
                                 report.type === 'negative' ? 'Complaint' : 'Incident Report'}
                              </span>
                              <span className="text-sm text-gray-500">{report.date}</span>
                            </div>
                            <p className="text-gray-700 text-sm">{report.description}</p>
                            <div className="flex items-center text-xs text-gray-500 mt-2">
                              <MapPin className="h-3 w-3 mr-1" />
                              {report.location}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No reports available for this profile.</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'trends' && (
              <div className="space-y-6">
                <h3 className="font-bold text-gray-900">Performance Trends</h3>
                <div className="bg-gray-50 p-8 rounded-lg text-center">
                  <TrendingUp className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Trend analysis visualization would be displayed here.</p>
                  <p className="text-sm text-gray-500 mt-2">Interactive charts showing score changes over time.</p>
                </div>
              </div>
            )}

            {activeTab === 'verification' && (
              <div className="space-y-6">
                <h3 className="font-bold text-gray-900">Verification Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-green-50 p-6 rounded-lg">
                    <div className="flex items-center space-x-3 mb-4">
                      <Shield className="h-6 w-6 text-green-600" />
                      <span className="font-bold text-green-900">Verified Profile</span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Identity Verified</span>
                        <span className="text-green-600">✓</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Department Confirmed</span>
                        <span className="text-green-600">✓</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Reports Validated</span>
                        <span className="text-green-600">✓</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-blue-50 p-6 rounded-lg">
                    <h4 className="font-bold text-gray-900 mb-4">Verification Details</h4>
                    <div className="space-y-2 text-sm text-gray-700">
                      <p>Last verified: January 15, 2025</p>
                      <p>Verification method: Government database</p>
                      <p>Confidence level: 98%</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};