import React from 'react';
import { Shield, Users, BarChart3, Eye, Award, Search, ArrowRight, CheckCircle, Camera, MapPin, TrendingUp } from 'lucide-react';

interface LandingPageProps {
  onNavigate: (page: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onNavigate }) => {
  const features = [
    {
      icon: Shield,
      title: 'Civic Score System',
      description: 'AI-powered scoring from 0-1000 that tracks public servant accountability and behavior patterns.',
      image: 'https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: Users,
      title: 'Crowd-Verified Reviews',
      description: 'Community-driven feedback system with advanced moderation to ensure authentic, verified reports.',
      image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: Eye,
      title: 'Whistleblower Protection',
      description: 'Anonymous reporting with encryption and tamper-proof storage for sensitive accountability issues.',
      image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: Award,
      title: 'Civic Hero Recognition',
      description: 'Celebrate and recognize outstanding public servants who consistently serve with integrity.',
      image: 'https://images.pexels.com/photos/1181533/pexels-photo-1181533.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: BarChart3,
      title: 'Real-Time Analytics',
      description: 'Comprehensive dashboards showing trends, patterns, and improvement areas across regions.',
      image: 'https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      icon: Search,
      title: 'Smart Search & Discovery',
      description: 'Find and verify public servants with detailed profiles, history, and accountability metrics.',
      image: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  const stats = [
    { number: '50K+', label: 'Verified Reports' },
    { number: '12K+', label: 'Public Servants Tracked' },
    { number: '95%', label: 'Accuracy Rate' },
    { number: '24/7', label: 'Real-Time Monitoring' },
  ];

  const testimonials = [
    {
      quote: "CivicLens has transformed how we hold our public servants accountable. The transparency is unprecedented.",
      author: "Dr. Priya Sharma",
      role: "Civil Rights Activist",
      image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=100'
    },
    {
      quote: "As a police officer, I appreciate the fair scoring system that recognizes good work alongside accountability.",
      author: "Inspector Raj Kumar",
      role: "Mumbai Police",
      image: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100'
    },
    {
      quote: "The whistleblower feature gave me the courage to report corruption safely. This platform saves lives.",
      author: "Anonymous Citizen",
      role: "Verified User",
      image: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100'
    }
  ];

  const useCases = [
    {
      title: 'Police Accountability',
      description: 'Track officer behavior, response times, and community interactions',
      image: 'https://images.pexels.com/photos/8112199/pexels-photo-8112199.jpeg?auto=compress&cs=tinysrgb&w=500',
      stats: '2,847 Officers Tracked'
    },
    {
      title: 'Government Services',
      description: 'Monitor municipal workers, clerks, and public service delivery',
      image: 'https://images.pexels.com/photos/8112198/pexels-photo-8112198.jpeg?auto=compress&cs=tinysrgb&w=500',
      stats: '1,234 Officials Monitored'
    },
    {
      title: 'Healthcare Workers',
      description: 'Ensure quality care and professional conduct in public hospitals',
      image: 'https://images.pexels.com/photos/4173251/pexels-photo-4173251.jpeg?auto=compress&cs=tinysrgb&w=500',
      stats: '892 Healthcare Workers'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-blue-800 opacity-5"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-8">
                <div className="p-4 bg-blue-600 rounded-full mr-4">
                  <Shield className="h-12 w-12 text-white" />
                </div>
                <h1 className="text-5xl md:text-6xl font-bold text-gray-900 tracking-tight">
                  Civic<span className="text-blue-600">Lens</span>
                </h1>
              </div>
              <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed">
                The AI-powered platform bringing radical accountability to public life through 
                <span className="text-blue-600 font-semibold"> crowdsourced civic scoring</span> and transparent governance.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center space-x-2"
                >
                  <span>Explore Platform</span>
                  <ArrowRight className="h-5 w-5" />
                </button>
                <button
                  onClick={() => onNavigate('search')}
                  className="border-2 border-blue-600 text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-50 transition-all duration-300 flex items-center justify-center space-x-2"
                >
                  <Search className="h-5 w-5" />
                  <span>Search Profiles</span>
                </button>
              </div>
            </div>
            
            {/* Hero Image */}
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.pexels.com/photos/5668473/pexels-photo-5668473.jpeg?auto=compress&cs=tinysrgb&w=600" 
                  alt="Civic accountability dashboard"
                  className="w-full h-96 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/50 to-transparent"></div>
                <div className="absolute bottom-6 left-6 text-white">
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium">Live Monitoring Active</span>
                  </div>
                  <p className="text-lg font-semibold">Real-time civic accountability tracking</p>
                </div>
              </div>
              
              {/* Floating Stats Cards */}
              <div className="absolute -top-4 -right-4 bg-white rounded-lg shadow-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <div>
                    <div className="text-lg font-bold text-gray-900">987</div>
                    <div className="text-xs text-gray-600">Avg Civic Score</div>
                  </div>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-white rounded-lg shadow-lg p-4 border border-gray-200">
                <div className="flex items-center space-x-2">
                  <Camera className="h-5 w-5 text-blue-500" />
                  <div>
                    <div className="text-lg font-bold text-gray-900">12.8K</div>
                    <div className="text-xs text-gray-600">Reports Today</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index} className="p-6">
                <div className="text-3xl md:text-4xl font-bold text-blue-600 mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Transforming Public Accountability
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              See how CivicLens is making a difference across different sectors
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {useCases.map((useCase, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 group">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={useCase.image} 
                    alt={useCase.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <div className="text-sm font-medium">{useCase.stats}</div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{useCase.title}</h3>
                  <p className="text-gray-600">{useCase.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Revolutionary Features for Civic Accountability
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Powered by AI, secured by blockchain, and driven by community participation.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 group">
                <div className="relative mb-6">
                  <img 
                    src={feature.image} 
                    alt={feature.title}
                    className="w-full h-32 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 left-3 p-2 bg-white/90 backdrop-blur-sm rounded-lg">
                    <feature.icon className="h-5 w-5 text-blue-600" />
                  </div>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-4">{feature.title}</h3>
                <p className="text-gray-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How CivicLens Works</h2>
            <p className="text-xl text-gray-600">Simple, secure, and transparent accountability</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center group">
              <div className="relative mb-6">
                <div className="w-24 h-24 bg-blue-600 rounded-full mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <span className="text-white text-2xl font-bold">1</span>
                </div>
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                  <img 
                    src="https://images.pexels.com/photos/4348401/pexels-photo-4348401.jpeg?auto=compress&cs=tinysrgb&w=200" 
                    alt="Report submission"
                    className="w-16 h-16 rounded-full border-4 border-white shadow-lg"
                  />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 mt-8">Report & Review</h3>
              <p className="text-gray-600">Submit verified reports with photos, context, and evidence about public servant interactions.</p>
            </div>
            
            <div className="text-center group">
              <div className="relative mb-6">
                <div className="w-24 h-24 bg-blue-600 rounded-full mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <span className="text-white text-2xl font-bold">2</span>
                </div>
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                  <img 
                    src="https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=200" 
                    alt="AI processing"
                    className="w-16 h-16 rounded-full border-4 border-white shadow-lg"
                  />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 mt-8">AI Processing</h3>
              <p className="text-gray-600">Advanced AI algorithms verify, moderate, and calculate dynamic Civic Scores based on patterns.</p>
            </div>
            
            <div className="text-center group">
              <div className="relative mb-6">
                <div className="w-24 h-24 bg-blue-600 rounded-full mx-auto flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                  <span className="text-white text-2xl font-bold">3</span>
                </div>
                <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
                  <img 
                    src="https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=200" 
                    alt="Transparent results"
                    className="w-16 h-16 rounded-full border-4 border-white shadow-lg"
                  />
                </div>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4 mt-8">Transparent Results</h3>
              <p className="text-gray-600">Public profiles, trend analysis, and accountability metrics drive systemic improvements.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What People Are Saying</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white p-8 rounded-xl shadow-lg border border-gray-100">
                <div className="flex items-center mb-4">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-green-600 font-medium">Verified Review</span>
                </div>
                <p className="text-gray-700 mb-6 italic">"{testimonial.quote}"</p>
                <div className="flex items-center space-x-3">
                  <img 
                    src={testimonial.image} 
                    alt={testimonial.author}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.author}</div>
                    <div className="text-sm text-gray-600">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 relative overflow-hidden">
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1200" 
            alt="Community engagement"
            className="w-full h-full object-cover opacity-20"
          />
        </div>
        <div className="relative max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Public Accountability?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Join thousands of citizens already making a difference with CivicLens.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('dashboard')}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-50 transition-all duration-300 shadow-lg"
            >
              Get Started Today
            </button>
            <button
              onClick={() => onNavigate('report')}
              className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-all duration-300"
            >
              Make Your First Report
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center items-center space-x-2 mb-4">
              <Shield className="h-8 w-8 text-blue-400" />
              <span className="text-2xl font-bold">CivicLens</span>
            </div>
            <p className="text-gray-400 mb-4">Bringing accountability to public service through AI and community</p>
            <p className="text-sm text-gray-500">© 2025 CivicLens. All rights reserved. Built for transparency and justice.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};