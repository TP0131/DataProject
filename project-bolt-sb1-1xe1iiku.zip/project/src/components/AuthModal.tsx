import React, { useState } from 'react';
import { X, Shield, Phone, Mail, Camera, CheckCircle, AlertCircle } from 'lucide-react';

interface AuthModalProps {
  onClose: () => void;
  onAuth: (success: boolean) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, onAuth }) => {
  const [step, setStep] = useState<'method' | 'phone' | 'email' | 'verification' | 'success'>('method');
  const [authMethod, setAuthMethod] = useState<'phone' | 'email'>('phone');
  const [formData, setFormData] = useState({
    phone: '',
    email: '',
    verificationCode: '',
    name: '',
  });
  const [generatedCode, setGeneratedCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleMethodSelect = (method: 'phone' | 'email') => {
    setAuthMethod(method);
    setStep(method);
    setError('');
  };

  const generateVerificationCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const simulateEmailSend = async (email: string, code: string) => {
    // Simulate email sending delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In a real app, this would send an actual email
    console.log(`📧 Email sent to ${email} with code: ${code}`);
    
    // Show the code in console for demo purposes
    alert(`Demo Mode: Verification code sent to ${email}\nCode: ${code}\n\n(In production, this would be sent via email)`);
  };

  const simulateSmsSend = async (phone: string, code: string) => {
    // Simulate SMS sending delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // In a real app, this would send an actual SMS
    console.log(`📱 SMS sent to ${phone} with code: ${code}`);
    
    // Show the code in console for demo purposes
    alert(`Demo Mode: Verification code sent to ${phone}\nCode: ${code}\n\n(In production, this would be sent via SMS)`);
  };

  const handleSendVerification = async () => {
    if (authMethod === 'phone' && !formData.phone) {
      setError('Please enter a valid phone number');
      return;
    }
    if (authMethod === 'email' && !formData.email) {
      setError('Please enter a valid email address');
      return;
    }
    if (!formData.name) {
      setError('Please enter your full name');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const code = generateVerificationCode();
      setGeneratedCode(code);

      if (authMethod === 'phone') {
        await simulateSmsSend(formData.phone, code);
      } else {
        await simulateEmailSend(formData.email, code);
      }

      setStep('verification');
    } catch (err) {
      setError('Failed to send verification code. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerify = () => {
    if (formData.verificationCode !== generatedCode) {
      setError('Invalid verification code. Please try again.');
      return;
    }

    setError('');
    setStep('success');
    setTimeout(() => {
      onAuth(true);
    }, 2000);
  };

  const handleResendCode = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      const code = generateVerificationCode();
      setGeneratedCode(code);

      if (authMethod === 'phone') {
        await simulateSmsSend(formData.phone, code);
      } else {
        await simulateEmailSend(formData.email, code);
      }
    } catch (err) {
      setError('Failed to resend code. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <Shield className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">Secure Verification</h2>
                <p className="text-sm text-gray-600">Verify your identity to access CivicLens</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
              <AlertCircle className="h-4 w-4 text-red-500" />
              <span className="text-red-700 text-sm">{error}</span>
            </div>
          )}

          {step === 'method' && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Choose Verification Method</h3>
                <p className="text-gray-600">Select how you'd like to verify your identity</p>
              </div>

              <button
                onClick={() => handleMethodSelect('phone')}
                className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-blue-100 rounded-lg group-hover:bg-blue-200 transition-colors">
                    <Phone className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-gray-900">Phone Verification</div>
                    <div className="text-sm text-gray-600">Verify using your mobile number</div>
                  </div>
                </div>
              </button>

              <button
                onClick={() => handleMethodSelect('email')}
                className="w-full p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all group"
              >
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-green-100 rounded-lg group-hover:bg-green-200 transition-colors">
                    <Mail className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-gray-900">Email Verification</div>
                    <div className="text-sm text-gray-600">Verify using your email address</div>
                  </div>
                </div>
              </button>

              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <div className="flex items-start space-x-3">
                  <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-blue-900">Why verify?</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Verification ensures the integrity of our civic accountability system and prevents abuse.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {step === 'phone' && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Phone className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Phone Verification</h3>
                <p className="text-gray-600">Enter your mobile number to receive a verification code</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Mobile Number
                </label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                  placeholder="+91 9876543210"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter your full name"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <button
                onClick={handleSendVerification}
                disabled={!formData.phone || !formData.name || isLoading}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Sending Code...</span>
                  </>
                ) : (
                  <span>Send Verification Code</span>
                )}
              </button>

              <button
                onClick={() => setStep('method')}
                className="w-full text-gray-600 hover:text-gray-800 transition-colors"
              >
                ← Back to methods
              </button>
            </div>
          )}

          {step === 'email' && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <Mail className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Email Verification</h3>
                <p className="text-gray-600">Enter your email address to receive a verification code</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="you@example.com"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name
                </label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter your full name"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <button
                onClick={handleSendVerification}
                disabled={!formData.email || !formData.name || isLoading}
                className="w-full bg-green-600 text-white py-3 px-4 rounded-lg hover:bg-green-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    <span>Sending Code...</span>
                  </>
                ) : (
                  <span>Send Verification Code</span>
                )}
              </button>

              <button
                onClick={() => setStep('method')}
                className="w-full text-gray-600 hover:text-gray-800 transition-colors"
              >
                ← Back to methods
              </button>
            </div>
          )}

          {step === 'verification' && (
            <div className="space-y-4">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-8 w-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Enter Verification Code</h3>
                <p className="text-gray-600">
                  We've sent a 6-digit code to your {authMethod === 'phone' ? 'phone' : 'email'}
                </p>
                <p className="text-sm text-blue-600 mt-2">
                  {authMethod === 'phone' ? formData.phone : formData.email}
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Verification Code
                </label>
                <input
                  type="text"
                  value={formData.verificationCode}
                  onChange={(e) => setFormData(prev => ({ ...prev, verificationCode: e.target.value }))}
                  placeholder="Enter 6-digit code"
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-center text-2xl tracking-widest"
                  maxLength={6}
                />
              </div>

              <button
                onClick={handleVerify}
                disabled={formData.verificationCode.length !== 6}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Verify Code
              </button>

              <div className="text-center">
                <button 
                  onClick={handleResendCode}
                  disabled={isLoading}
                  className="text-blue-600 hover:text-blue-800 text-sm disabled:opacity-50"
                >
                  {isLoading ? 'Resending...' : "Didn't receive the code? Resend"}
                </button>
              </div>

              <div className="bg-yellow-50 p-3 rounded-lg">
                <p className="text-yellow-800 text-xs">
                  <strong>Demo Mode:</strong> The verification code has been displayed in an alert for testing purposes. 
                  In production, codes would be sent via actual SMS/email.
                </p>
              </div>
            </div>
          )}

          {step === 'success' && (
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                <CheckCircle className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900">Verification Successful!</h3>
              <p className="text-gray-600">
                Welcome to CivicLens! Your account has been verified and you now have full access to the platform.
              </p>
              <div className="bg-green-50 p-4 rounded-lg">
                <p className="text-green-800 text-sm">
                  🎉 You can now submit reports, access analytics, and use all CivicLens features.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};