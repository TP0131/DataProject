export interface Location {
  id: string;
  name: string;
  premium: boolean;
}

export const kolkataLocations: Location[] = [
  { id: 'salt-lake', name: 'Salt Lake', premium: true },
  { id: 'new-town', name: 'New Town', premium: true },
  { id: 'ballygunge', name: 'Ballygunge', premium: true },
  { id: 'alipore', name: 'Alipore', premium: true },
  { id: 'rajarhat', name: 'Rajarhat', premium: false },
  { id: 'behala', name: 'Behala', premium: false },
  { id: 'tollygunge', name: 'Tollygunge', premium: false },
  { id: 'lake-gardens', name: 'Lake Gardens', premium: true },
  { id: 'jadavpur', name: 'Jadavpur', premium: false },
  { id: 'garia', name: 'Garia', premium: false },
  { id: 'dum-dum', name: 'Dum Dum', premium: false },
  { id: 'barasat', name: 'Barasat', premium: false },
  { id: 'park-street', name: 'Park Street', premium: true },
  { id: 'bhowanipore', name: 'Bhowanipore', premium: true },
  { id: 'howrah', name: 'Howrah', premium: false },
  { id: 'sealdah', name: 'Sealdah', premium: false },
  { id: 'gariahat', name: 'Gariahat', premium: false },
  { id: 'kasba', name: 'Kasba', premium: false },
  { id: 'barrackpore', name: 'Barrackpore', premium: false },
  { id: 'konnagar', name: 'Konnagar', premium: false },
  { id: 'belur', name: 'Belur', premium: false },
  { id: 'bally', name: 'Bally', premium: false },
  { id: 'dunlop', name: 'Dunlop', premium: false },
  { id: 'ultadanga', name: 'Ultadanga', premium: false },
  { id: 'patuli', name: 'Patuli', premium: false },
  { id: 'ruby', name: 'Ruby', premium: false },
  { id: 'south-city', name: 'South City', premium: true },
  { id: 'jodhpur-park', name: 'Jodhpur Park', premium: false },
  { id: 'deshapriya-park', name: 'Deshapriya Park', premium: false },
  { id: 'southern-avenue', name: 'Southern Avenue', premium: true }
];