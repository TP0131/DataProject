import { useState } from 'react';
import { Home, Calendar, Ruler, Bath, MapPin, School, Trees as Tree, Shield, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import LocationSelector from './LocationSelector';
import { predictHousePrice } from '../utils/predictionModel';
import PredictionResult from './PredictionResult';
import { Property } from '../types';

const PredictionForm = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<Property>({
    id: '', // Will be generated on form submission
    location: 'Salt Lake',
    rooms: 3,
    bathrooms: 2,
    size: 1200,
    yearBuilt: 2010,
    schoolProximity: 3,
    parkProximity: 3,
    crimeRate: 2,
    roi: 0, // This will be calculated
    createdAt: '', // Will be set on form submission
    predictedPrice: 0, // Will be calculated
    priceRange: { min: 0, max: 0 } // Will be calculated
  });
  
  const [prediction, setPrediction] = useState<Property | null>(null);
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Generate a timestamp and ID for this prediction
      const timestamp = new Date().toISOString();
      const newProperty: Property = {
        ...formData,
        id: `pred_${Date.now()}`,
        createdAt: timestamp
      };
      
      // Calculate the prediction
      const result = await predictHousePrice(newProperty);
      
      // Update with prediction results
      setPrediction(result);
      
      // Save to localStorage if needed
      // const savedPredictions = JSON.parse(localStorage.getItem('savedPredictions') || '[]');
      // localStorage.setItem('savedPredictions', JSON.stringify([...savedPredictions, result]));
    } catch (error) {
      console.error('Prediction failed:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: name === 'location' ? value : Number(value)
    }));
  };
  
  const handleReset = () => {
    setPrediction(null);
    setFormData({
      id: '',
      location: 'Salt Lake',
      rooms: 3,
      bathrooms: 2,
      size: 1200,
      yearBuilt: 2010,
      schoolProximity: 3,
      parkProximity: 3,
      crimeRate: 2,
      roi: 0,
      createdAt: '',
      predictedPrice: 0,
      priceRange: { min: 0, max: 0 }
    });
  };
  
  const handleSavePrediction = () => {
    if (!prediction) return;
    
    // Save to localStorage
    const savedPredictions = JSON.parse(localStorage.getItem('savedPredictions') || '[]');
    localStorage.setItem('savedPredictions', JSON.stringify([...savedPredictions, prediction]));
    
    // Notify user
    alert('Prediction saved successfully!');
  };
  
  const handleCompare = () => {
    if (!prediction) return;
    
    // Save current prediction temporarily and navigate to compare page
    localStorage.setItem('currentPrediction', JSON.stringify(prediction));
    navigate('/compare');
  };

  return (
    <div id="prediction-form" className="bg-white rounded-lg shadow-lg p-6 md:p-8">
      {!prediction ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Property Details</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <LocationSelector 
              selectedLocation={formData.location} 
              onLocationChange={(location) => 
                setFormData((prev) => ({ ...prev, location }))
              } 
            />
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <Home size={18} className="mr-2 text-gray-500" />
                  Bedrooms
                </div>
              </label>
              <input
                type="number"
                name="rooms"
                min="1"
                max="10"
                value={formData.rooms}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <Bath size={18} className="mr-2 text-gray-500" />
                  Bathrooms
                </div>
              </label>
              <input
                type="number"
                name="bathrooms"
                min="1"
                max="8"
                step="0.5"
                value={formData.bathrooms}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <Ruler size={18} className="mr-2 text-gray-500" />
                  Size (sq. ft.)
                </div>
              </label>
              <input
                type="number"
                name="size"
                min="100"
                max="10000"
                step="50"
                value={formData.size}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <Calendar size={18} className="mr-2 text-gray-500" />
                  Year Built
                </div>
              </label>
              <input
                type="number"
                name="yearBuilt"
                min="1900"
                max={new Date().getFullYear()}
                value={formData.yearBuilt}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <School size={18} className="mr-2 text-gray-500" />
                  School Proximity
                </div>
              </label>
              <select
                name="schoolProximity"
                value={formData.schoolProximity}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              >
                <option value="1">Very Far</option>
                <option value="2">Far</option>
                <option value="3">Average</option>
                <option value="4">Close</option>
                <option value="5">Very Close</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <Tree size={18} className="mr-2 text-gray-500" />
                  Park Proximity
                </div>
              </label>
              <select
                name="parkProximity"
                value={formData.parkProximity}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              >
                <option value="1">Very Far</option>
                <option value="2">Far</option>
                <option value="3">Average</option>
                <option value="4">Close</option>
                <option value="5">Very Close</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                <div className="flex items-center">
                  <Shield size={18} className="mr-2 text-gray-500" />
                  Crime Rate
                </div>
              </label>
              <select
                name="crimeRate"
                value={formData.crimeRate}
                onChange={handleChange}
                className="w-full border-gray-300 rounded-md shadow-sm focus:ring-teal-500 focus:border-teal-500"
              >
                <option value="1">Very Low</option>
                <option value="2">Low</option>
                <option value="3">Medium</option>
                <option value="4">High</option>
                <option value="5">Very High</option>
              </select>
            </div>
          </div>
          
          <div className="flex justify-center pt-4">
            <button
              type="submit"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gradient-to-r from-blue-800 to-teal-600 hover:from-blue-700 hover:to-teal-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 shadow-md transition-all duration-300"
              disabled={loading}
            >
              {loading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Calculating...
                </>
              ) : (
                'Calculate Property Value'
              )}
            </button>
          </div>
        </form>
      ) : (
        <div className="space-y-8">
          <PredictionResult property={prediction} />
          
          <div className="flex flex-wrap justify-center gap-4 pt-4">
            <button
              onClick={handleReset}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Make Another Prediction
            </button>
            
            <button
              onClick={handleSavePrediction}
              className="px-4 py-2 border border-transparent rounded-md text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
            >
              Save This Prediction
            </button>
            
            <button
              onClick={handleCompare}
              className="px-4 py-2 border border-transparent rounded-md text-white bg-blue-900 hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
              Compare with Other Properties
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PredictionForm;