import { useState } from 'react';
import { MapPin } from 'lucide-react';
import { kolkataLocations } from '../data/locations';

type LocationSelectorProps = {
  selectedLocation: string;
  onLocationChange: (location: string) => void;
};

const LocationSelector = ({ selectedLocation, onLocationChange }: LocationSelectorProps) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLocations = kolkataLocations.filter(
    location => location.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="relative">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Location
      </label>
      
      <div className="relative">
        <div 
          className="flex items-center border rounded-md border-gray-300 px-3 py-2 bg-white shadow-sm cursor-pointer w-full focus-within:ring-2 focus-within:ring-teal-500 focus-within:border-teal-500"
          onClick={() => setShowDropdown(!showDropdown)}
        >
          <MapPin size={18} className="text-gray-400 mr-2" />
          <input
            type="text"
            className="w-full border-0 p-0 focus:ring-0 focus:outline-none"
            placeholder="Select neighborhood"
            value={searchTerm || selectedLocation}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setShowDropdown(true);
            }}
            onClick={(e) => e.stopPropagation()}
          />
        </div>
        
        {showDropdown && (
          <div className="absolute mt-1 w-full bg-white rounded-md shadow-lg max-h-60 overflow-auto z-10 border border-gray-200">
            {filteredLocations.length > 0 ? (
              filteredLocations.map((location) => (
                <div
                  key={location.id}
                  className="px-4 py-2 cursor-pointer hover:bg-gray-100 flex items-center"
                  onClick={() => {
                    onLocationChange(location.name);
                    setSearchTerm('');
                    setShowDropdown(false);
                  }}
                >
                  <span>{location.name}</span>
                  {location.premium && (
                    <span className="ml-2 px-2 py-0.5 text-xs font-medium bg-amber-100 text-amber-800 rounded-full">
                      Premium
                    </span>
                  )}
                </div>
              ))
            ) : (
              <div className="px-4 py-2 text-gray-500">No locations found</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default LocationSelector;