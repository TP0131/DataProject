import { useState, useEffect } from 'react';
import { Home, TrendingUp, MapPin, Calendar, Ruler, School, Shield } from 'lucide-react';
import { Property } from '../types';
import PriceGauge from './PriceGauge';
import { formatCurrency } from '../utils/formatters';

type PredictionResultProps = {
  property: Property;
};

const PredictionResult = ({ property }: PredictionResultProps) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const {
    location,
    rooms,
    bathrooms,
    size,
    yearBuilt,
    schoolProximity,
    parkProximity,
    crimeRate,
    roi,
    predictedPrice,
    priceRange
  } = property;

  // Calculate price per square foot
  const pricePerSqFt = predictedPrice / size;

  return (
    <div 
      className={`transition-all duration-700 transform ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
      }`}
    >
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Property Value Analysis</h2>
      
      <div className="mb-8">
        <PriceGauge 
          value={predictedPrice} 
          minValue={priceRange.min} 
          maxValue={priceRange.max} 
        />
        
        <div className="text-center mt-4">
          <div className="text-3xl font-bold text-blue-900">
            {formatCurrency(predictedPrice)}
          </div>
          <div className="text-gray-500 mt-1">
            Estimated Value
          </div>
          
          <div className="flex justify-center items-center gap-2 mt-2">
            <span className="px-3 py-1 text-sm font-medium bg-teal-100 text-teal-800 rounded-full">
              {formatCurrency(pricePerSqFt)} per sq.ft
            </span>
            
            <span className="px-3 py-1 text-sm font-medium bg-amber-100 text-amber-800 rounded-full flex items-center">
              <TrendingUp size={14} className="mr-1" />
              {roi}% ROI
            </span>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 text-gray-900">Property Details</h3>
          
          <div className="space-y-3">
            <div className="flex items-center">
              <MapPin size={18} className="text-gray-500 mr-2" />
              <span className="text-gray-700">Location:</span>
              <span className="ml-auto font-semibold">{location}</span>
            </div>
            
            <div className="flex items-center">
              <Home size={18} className="text-gray-500 mr-2" />
              <span className="text-gray-700">Bedrooms:</span>
              <span className="ml-auto font-semibold">{rooms}</span>
            </div>
            
            <div className="flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
              </svg>
              <span className="text-gray-700">Bathrooms:</span>
              <span className="ml-auto font-semibold">{bathrooms}</span>
            </div>
            
            <div className="flex items-center">
              <Ruler size={18} className="text-gray-500 mr-2" />
              <span className="text-gray-700">Size:</span>
              <span className="ml-auto font-semibold">{size} sq.ft</span>
            </div>
            
            <div className="flex items-center">
              <Calendar size={18} className="text-gray-500 mr-2" />
              <span className="text-gray-700">Year Built:</span>
              <span className="ml-auto font-semibold">{yearBuilt}</span>
            </div>
          </div>
        </div>
        
        <div className="rounded-lg border border-gray-200 bg-white p-4 shadow-sm">
          <h3 className="text-lg font-semibold mb-4 text-gray-900">Area Factors</h3>
          
          <div className="space-y-4">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 flex items-center">
                  <School size={16} className="mr-1" /> School Proximity
                </span>
                <span className="text-sm font-medium text-gray-700">
                  {['Very Far', 'Far', 'Average', 'Close', 'Very Close'][schoolProximity-1]}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-teal-600 h-2 rounded-full" 
                  style={{ width: `${schoolProximity * 20}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                  </svg>
                  Park Proximity
                </span>
                <span className="text-sm font-medium text-gray-700">
                  {['Very Far', 'Far', 'Average', 'Close', 'Very Close'][parkProximity-1]}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-green-600 h-2 rounded-full" 
                  style={{ width: `${parkProximity * 20}%` }}
                ></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 flex items-center">
                  <Shield size={16} className="mr-1" /> Crime Rate
                </span>
                <span className="text-sm font-medium text-gray-700">
                  {['Very Low', 'Low', 'Medium', 'High', 'Very High'][crimeRate-1]}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className={`h-2 rounded-full ${
                    crimeRate <= 2 
                      ? 'bg-green-600' 
                      : crimeRate === 3 
                        ? 'bg-yellow-500' 
                        : 'bg-red-500'
                  }`} 
                  style={{ width: `${crimeRate * 20}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-blue-50 border border-blue-100 rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-2 text-blue-900">Analysis Insights</h3>
        <p className="text-blue-800">
          This {rooms}-bedroom property in {location} is {
            predictedPrice > priceRange.min + (priceRange.max - priceRange.min) * 0.7 
              ? 'among the higher-valued properties' 
              : predictedPrice < priceRange.min + (priceRange.max - priceRange.min) * 0.3
                ? 'more affordable compared to similar properties'
                : 'reasonably priced'
          } in this area. {
            yearBuilt < 2000 
              ? 'Being an older construction, renovations could significantly increase its value.' 
              : 'Its relatively modern construction contributes positively to its valuation.'
          } {
            schoolProximity >= 4 
              ? 'The excellent proximity to schools is a strong selling point.' 
              : schoolProximity <= 2
                ? 'The property value is somewhat affected by the distance from schools.'
                : ''
          } {
            crimeRate <= 2 
              ? 'The low crime rate in this area positively impacts property value.' 
              : crimeRate >= 4
                ? 'The higher crime rate in this area is a factor in the valuation.'
                : ''
          }
        </p>
      </div>
    </div>
  );
};

export default PredictionResult;