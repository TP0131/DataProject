import { useState, useEffect } from 'react';
import { formatCurrency } from '../utils/formatters';

type PriceGaugeProps = {
  value: number;
  minValue: number;
  maxValue: number;
};

const PriceGauge = ({ value, minValue, maxValue }: PriceGaugeProps) => {
  const [percentage, setPercentage] = useState(0);
  
  useEffect(() => {
    // Calculate percentage and cap it between 0 and 100
    const range = maxValue - minValue;
    const rawPercentage = ((value - minValue) / range) * 100;
    
    // Animate the gauge
    let startPercentage = 0;
    const duration = 1500; // 1.5 seconds
    const interval = 16; // ~60fps
    const steps = duration / interval;
    let step = 0;
    
    const timer = setInterval(() => {
      step++;
      const newPercentage = Math.min(
        100,
        Math.max(0, (step / steps) * rawPercentage)
      );
      setPercentage(newPercentage);
      
      if (step >= steps) {
        clearInterval(timer);
      }
    }, interval);
    
    return () => clearInterval(timer);
  }, [value, minValue, maxValue]);

  // Colors based on percentage
  const getColor = (pct: number) => {
    if (pct < 25) return 'from-green-500 to-green-300';
    if (pct < 50) return 'from-teal-500 to-green-300';
    if (pct < 75) return 'from-blue-500 to-teal-300';
    return 'from-blue-700 to-blue-400';
  };

  return (
    <div className="w-full py-4">
      <div className="relative h-4 bg-gray-200 rounded-full overflow-hidden">
        <div 
          className={`h-full rounded-full bg-gradient-to-r ${getColor(percentage)} transition-all duration-300 ease-out`}
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
      
      <div className="flex justify-between mt-2 text-sm text-gray-600">
        <div>{formatCurrency(minValue)}</div>
        <div className="font-medium">Market Range</div>
        <div>{formatCurrency(maxValue)}</div>
      </div>
    </div>
  );
};

export default PriceGauge;