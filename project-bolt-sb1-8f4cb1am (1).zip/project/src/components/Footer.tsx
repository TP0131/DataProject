import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-teal-400 bg-clip-text text-transparent">
              KolkataHomes
            </h3>
            <p className="text-gray-300 mb-4">
              Accurate property price predictions for the Kolkata housing market.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="text-gray-300 hover:text-teal-400 transition-colors"
                aria-label="Facebook"
              >
                <Facebook size={20} />
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-teal-400 transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a 
                href="#" 
                className="text-gray-300 hover:text-teal-400 transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={20} />
              </a>
              <a 
                href="mailto:info@kolkatahomes.com" 
                className="text-gray-300 hover:text-teal-400 transition-colors"
                aria-label="Email"
              >
                <Mail size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-300 hover:text-teal-400 transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-gray-300 hover:text-teal-400 transition-colors">About Us</Link></li>
              <li><Link to="/compare" className="text-gray-300 hover:text-teal-400 transition-colors">Compare Properties</Link></li>
              <li><Link to="/saved" className="text-gray-300 hover:text-teal-400 transition-colors">Saved Predictions</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Popular Areas</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-300 hover:text-teal-400 transition-colors">Salt Lake</a></li>
              <li><a href="#" className="text-gray-300 hover:text-teal-400 transition-colors">New Town</a></li>
              <li><a href="#" className="text-gray-300 hover:text-teal-400 transition-colors">Ballygunge</a></li>
              <li><a href="#" className="text-gray-300 hover:text-teal-400 transition-colors">Alipore</a></li>
              <li><a href="#" className="text-gray-300 hover:text-teal-400 transition-colors">Rajarhat</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <address className="not-italic text-gray-300">
              <p>123 Park Street</p>
              <p>Kolkata, West Bengal 700016</p>
              <p className="mt-2">Phone: +91 33 1234 5678</p>
              <p>Email: info@kolkatahomes.com</p>
            </address>
          </div>
        </div>
        
        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>&copy; {new Date().getFullYear()} KolkataHomes. All rights reserved.</p>
          <p className="mt-2">
            <Link to="#" className="hover:text-teal-400 transition-colors">Privacy Policy</Link>
            {' | '}
            <Link to="#" className="hover:text-teal-400 transition-colors">Terms of Service</Link>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;