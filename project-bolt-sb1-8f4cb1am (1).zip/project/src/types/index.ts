export interface Property {
  id: string;
  location: string;
  rooms: number;
  bathrooms: number;
  size: number;
  yearBuilt: number;
  schoolProximity: number; // 1-5 scale
  parkProximity: number; // 1-5 scale
  crimeRate: number; // 1-5 scale
  roi: number; // percentage
  createdAt: string;
  predictedPrice: number;
  priceRange: {
    min: number;
    max: number;
  };
}