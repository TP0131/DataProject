import { Building, TrendingUp, Users, History, BarChart2, MapPin } from 'lucide-react';

const About = () => {
  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-teal-800 text-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl font-bold mb-6">About KolkataHomes</h1>
            <p className="text-xl mb-8">
              We are revolutionizing real estate decisions in Kolkata with data-driven 
              property valuation and market insights.
            </p>
          </div>
        </div>
      </section>
      
      {/* Mission Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-lg shadow-md p-8 mb-12">
              <h2 className="text-3xl font-bold mb-6 text-center text-gray-900">Our Mission</h2>
              <p className="text-xl text-gray-700 text-center">
                To empower home buyers, sellers, and investors in Kolkata with accurate, 
                data-driven insights that lead to confident real estate decisions.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <div className="bg-white rounded-lg shadow-sm p-6 text-center hover:shadow-md transition-all duration-300">
                <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-blue-100 text-blue-900 rounded-full">
                  <Building size={28} />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Local Expertise</h3>
                <p className="text-gray-600">
                  Deep understanding of Kolkata's unique neighborhoods, property trends, and market dynamics.
                </p>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 text-center hover:shadow-md transition-all duration-300">
                <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-teal-100 text-teal-900 rounded-full">
                  <BarChart2 size={28} />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">Data Science</h3>
                <p className="text-gray-600">
                  Advanced predictive models built on comprehensive datasets specific to Kolkata real estate.
                </p>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-6 text-center hover:shadow-md transition-all duration-300">
                <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-amber-100 text-amber-900 rounded-full">
                  <Users size={28} />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-gray-900">User-Centric</h3>
                <p className="text-gray-600">
                  Designed for both professionals and individuals to make complex property data accessible to all.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* How It Works Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">
              Our prediction model combines multiple data sources and advanced algorithms
              to give you accurate property valuations.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="relative">
              {/* Timeline Line */}
              <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-gray-200"></div>
              
              {/* Steps */}
              <div className="relative z-10">
                {/* Step 1 */}
                <div className="md:flex md:items-center mb-12">
                  <div className="md:w-1/2 md:pr-8 md:text-right">
                    <h3 className="text-xl font-semibold mb-2 text-blue-900">Data Collection</h3>
                    <p className="text-gray-600">
                      We gather comprehensive property data from across Kolkata, including historical 
                      sales, neighborhood statistics, and market trends.
                    </p>
                  </div>
                  <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2">
                    <div className="w-12 h-12 rounded-full border-4 border-teal-500 bg-white flex items-center justify-center">
                      <span className="text-teal-500 font-bold">1</span>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:w-1/2 md:pl-8">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <ul className="list-disc list-inside text-gray-700">
                        <li>Historical property transactions</li>
                        <li>Government property records</li>
                        <li>Neighborhood amenities data</li>
                        <li>Infrastructure developments</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                {/* Step 2 */}
                <div className="md:flex md:items-center mb-12">
                  <div className="md:w-1/2 md:pr-8 md:text-right order-1 md:order-2">
                    <div className="bg-teal-50 p-4 rounded-lg">
                      <ul className="list-disc list-inside text-gray-700">
                        <li>Feature correlation analysis</li>
                        <li>Regression modeling</li>
                        <li>Anomaly detection</li>
                        <li>Predictive algorithms</li>
                      </ul>
                    </div>
                  </div>
                  <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2">
                    <div className="w-12 h-12 rounded-full border-4 border-teal-500 bg-white flex items-center justify-center">
                      <span className="text-teal-500 font-bold">2</span>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:w-1/2 md:pl-8 order-2 md:order-1">
                    <h3 className="text-xl font-semibold mb-2 text-blue-900">Model Training</h3>
                    <p className="text-gray-600">
                      Our data scientists build and refine algorithms specifically calibrated 
                      for Kolkata's unique real estate market.
                    </p>
                  </div>
                </div>
                
                {/* Step 3 */}
                <div className="md:flex md:items-center mb-12">
                  <div className="md:w-1/2 md:pr-8 md:text-right">
                    <h3 className="text-xl font-semibold mb-2 text-blue-900">Prediction Generation</h3>
                    <p className="text-gray-600">
                      When you input your property details, our system analyzes over 20 factors
                      to generate an accurate valuation.
                    </p>
                  </div>
                  <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2">
                    <div className="w-12 h-12 rounded-full border-4 border-teal-500 bg-white flex items-center justify-center">
                      <span className="text-teal-500 font-bold">3</span>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:w-1/2 md:pl-8">
                    <div className="bg-amber-50 p-4 rounded-lg">
                      <ul className="list-disc list-inside text-gray-700">
                        <li>Real-time data analysis</li>
                        <li>Confidence interval calculation</li>
                        <li>Comparable property matching</li>
                        <li>Value adjustment factors</li>
                      </ul>
                    </div>
                  </div>
                </div>
                
                {/* Step 4 */}
                <div className="md:flex md:items-center">
                  <div className="md:w-1/2 md:pr-8 md:text-right order-1 md:order-2">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <ul className="list-disc list-inside text-gray-700">
                        <li>Visual price range indicators</li>
                        <li>Neighborhood insights</li>
                        <li>Investment potential metrics</li>
                        <li>Comparable property suggestions</li>
                      </ul>
                    </div>
                  </div>
                  <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2">
                    <div className="w-12 h-12 rounded-full border-4 border-teal-500 bg-white flex items-center justify-center">
                      <span className="text-teal-500 font-bold">4</span>
                    </div>
                  </div>
                  <div className="mt-4 md:mt-0 md:w-1/2 md:pl-8 order-2 md:order-1">
                    <h3 className="text-xl font-semibold mb-2 text-blue-900">Results Visualization</h3>
                    <p className="text-gray-600">
                      We present your property's valuation with detailed insights, 
                      comparative analysis, and investment potential.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Location Coverage */}
      <section className="py-16 bg-gradient-to-r from-blue-900 to-teal-800 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Kolkata Areas We Cover</h2>
            <p className="text-xl opacity-90">
              Our prediction model has comprehensive data coverage across all major 
              neighborhoods in Kolkata.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {[
                'Salt Lake', 'New Town', 'Ballygunge', 'Alipore', 'Rajarhat', 
                'Behala', 'Tollygunge', 'Lake Gardens', 'Jadavpur', 'Garia', 
                'Dum Dum', 'Barasat', 'Park Street', 'Bhowanipore', 'Howrah', 
                'Sealdah', 'Gariahat', 'Kasba', 'Barrackpore', 'Konnagar'
              ].map((area) => (
                <div 
                  key={area}
                  className="bg-white bg-opacity-10 rounded-lg px-4 py-3 text-center backdrop-blur-sm border border-white border-opacity-20"
                >
                  <div className="flex items-center justify-center">
                    <MapPin size={16} className="mr-2 opacity-70" />
                    <span className="font-medium">{area}</span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="text-center mt-8">
              <p className="italic opacity-80">
                * And many more neighborhoods across the greater Kolkata metropolitan area
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Ready to Get Your Property's Valuation?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Discover your property's true market value with our accurate prediction model.
            </p>
            <a
              href="/"
              className="inline-flex items-center px-6 py-3 border border-transparent text-lg font-medium rounded-md text-white bg-gradient-to-r from-blue-800 to-teal-600 hover:from-blue-700 hover:to-teal-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 shadow-md transition-all duration-300"
            >
              Make a Prediction Now
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;