import { useState, useEffect } from 'react';
import { ArrowLeft, PlusCircle, BarChart2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Property } from '../types';
import { formatCurrency } from '../utils/formatters';

const CompareProperties = () => {
  const [currentProperty, setCurrentProperty] = useState<Property | null>(null);
  const [savedProperties, setSavedProperties] = useState<Property[]>([]);
  const [selectedProperties, setSelectedProperties] = useState<Property[]>([]);
  
  useEffect(() => {
    // Load current prediction if exists
    const currentPredictionJson = localStorage.getItem('currentPrediction');
    if (currentPredictionJson) {
      const parsedProperty = JSON.parse(currentPredictionJson);
      setCurrentProperty(parsedProperty);
      setSelectedProperties([parsedProperty]);
    }
    
    // Load saved predictions
    const savedPredictionsJson = localStorage.getItem('savedPredictions');
    if (savedPredictionsJson) {
      const parsedProperties = JSON.parse(savedPredictionsJson);
      setSavedProperties(parsedProperties);
    }
  }, []);
  
  const togglePropertySelection = (property: Property) => {
    if (selectedProperties.some(p => p.id === property.id)) {
      setSelectedProperties(selectedProperties.filter(p => p.id !== property.id));
    } else {
      if (selectedProperties.length < 3) {
        setSelectedProperties([...selectedProperties, property]);
      } else {
        alert('You can compare up to 3 properties at a time');
      }
    }
  };
  
  const isSelected = (property: Property) => {
    return selectedProperties.some(p => p.id === property.id);
  };
  
  const getHighestValue = (propertyKey: keyof Property) => {
    if (!selectedProperties.length) return 0;
    
    let highestValue = Number(selectedProperties[0][propertyKey]) || 0;
    
    selectedProperties.forEach(property => {
      const value = Number(property[propertyKey]) || 0;
      if (value > highestValue) {
        highestValue = value;
      }
    });
    
    return highestValue;
  };
  
  // Get best property for each attribute
  const getBestProperty = (propertyKey: keyof Property, isHigherBetter: boolean = true) => {
    if (!selectedProperties.length) return null;
    
    let bestProperty = selectedProperties[0];
    let bestValue = Number(selectedProperties[0][propertyKey]) || 0;
    
    selectedProperties.forEach(property => {
      const value = Number(property[propertyKey]) || 0;
      if (isHigherBetter ? value > bestValue : value < bestValue) {
        bestValue = value;
        bestProperty = property;
      }
    });
    
    return bestProperty.id;
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center text-blue-900 hover:text-blue-700">
            <ArrowLeft size={20} className="mr-2" />
            <span>Back to Home</span>
          </Link>
          
          <h1 className="text-3xl font-bold text-gray-900 mt-4 mb-2">Compare Properties</h1>
          <p className="text-gray-600">
            Select up to 3 properties to compare their features and valuations side by side.
          </p>
        </div>
        
        {/* Property Selection Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Available Properties</h2>
          
          {savedProperties.length === 0 && !currentProperty ? (
            <div className="text-center py-8">
              <div className="text-gray-500 mb-4">
                You don't have any saved properties to compare yet.
              </div>
              <Link
                to="/"
                className="inline-flex items-center px-4 py-2 bg-blue-900 text-white rounded-md hover:bg-blue-800"
              >
                <PlusCircle size={18} className="mr-2" />
                Create a Prediction
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentProperty && (
                <div 
                  className={`border rounded-lg p-4 cursor-pointer transition-all duration-300 ${
                    isSelected(currentProperty)
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 hover:border-teal-300 hover:bg-gray-50'
                  }`}
                  onClick={() => togglePropertySelection(currentProperty)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold">{currentProperty.location}</h3>
                      <p className="text-sm text-gray-500">Current Prediction</p>
                    </div>
                    <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center">
                      {isSelected(currentProperty) && (
                        <div className="w-3 h-3 bg-teal-500 rounded-full"></div>
                      )}
                    </div>
                  </div>
                  <div className="text-lg font-bold text-blue-900">
                    {formatCurrency(currentProperty.predictedPrice)}
                  </div>
                  <div className="text-sm mt-2">
                    <span className="inline-block mr-4">{currentProperty.rooms} BR</span>
                    <span className="inline-block mr-4">{currentProperty.bathrooms} Bath</span>
                    <span className="inline-block">{currentProperty.size} sq.ft</span>
                  </div>
                </div>
              )}
              
              {savedProperties
                .filter(p => !currentProperty || p.id !== currentProperty.id)
                .map((property) => (
                <div 
                  key={property.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-all duration-300 ${
                    isSelected(property)
                      ? 'border-teal-500 bg-teal-50'
                      : 'border-gray-200 hover:border-teal-300 hover:bg-gray-50'
                  }`}
                  onClick={() => togglePropertySelection(property)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h3 className="font-semibold">{property.location}</h3>
                      <p className="text-sm text-gray-500">
                        Saved on {new Date(property.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="w-5 h-5 rounded-full border-2 flex items-center justify-center">
                      {isSelected(property) && (
                        <div className="w-3 h-3 bg-teal-500 rounded-full"></div>
                      )}
                    </div>
                  </div>
                  <div className="text-lg font-bold text-blue-900">
                    {formatCurrency(property.predictedPrice)}
                  </div>
                  <div className="text-sm mt-2">
                    <span className="inline-block mr-4">{property.rooms} BR</span>
                    <span className="inline-block mr-4">{property.bathrooms} Bath</span>
                    <span className="inline-block">{property.size} sq.ft</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Comparison Chart Section */}
        {selectedProperties.length > 0 && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-semibold">Property Comparison</h2>
              <div className="flex items-center">
                <BarChart2 size={20} className="text-blue-900 mr-2" />
                <span className="text-gray-600">
                  Comparing {selectedProperties.length} {selectedProperties.length === 1 ? 'property' : 'properties'}
                </span>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Feature
                    </th>
                    {selectedProperties.map((property, index) => (
                      <th 
                        key={property.id} 
                        scope="col" 
                        className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
                      >
                        Property {index + 1}: {property.location}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {/* Price Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Predicted Price
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('predictedPrice', false) === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {formatCurrency(property.predictedPrice)}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Price per sq ft Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Price per sq ft
                    </td>
                    {selectedProperties.map((property) => {
                      const pricePerSqFt = property.predictedPrice / property.size;
                      return (
                        <td 
                          key={property.id} 
                          className={`px-4 py-4 whitespace-nowrap text-sm ${
                            getBestProperty('size', false) === property.id
                              ? 'text-green-600 font-semibold'
                              : 'text-gray-900'
                          }`}
                        >
                          {formatCurrency(pricePerSqFt)}
                        </td>
                      );
                    })}
                  </tr>
                  
                  {/* Location Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Location
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className="px-4 py-4 whitespace-nowrap text-sm text-gray-900"
                      >
                        {property.location}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Size Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Size (sq ft)
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('size') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {property.size}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Bedrooms Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Bedrooms
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('rooms') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {property.rooms}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Bathrooms Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Bathrooms
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('bathrooms') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {property.bathrooms}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Year Built Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Year Built
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('yearBuilt') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {property.yearBuilt}
                      </td>
                    ))}
                  </tr>
                  
                  {/* ROI Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Projected ROI (%)
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('roi') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {property.roi}%
                      </td>
                    ))}
                  </tr>
                  
                  {/* School Proximity Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      School Proximity
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('schoolProximity') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {['Very Far', 'Far', 'Average', 'Close', 'Very Close'][property.schoolProximity-1]}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Park Proximity Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Park Proximity
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('parkProximity') === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {['Very Far', 'Far', 'Average', 'Close', 'Very Close'][property.parkProximity-1]}
                      </td>
                    ))}
                  </tr>
                  
                  {/* Crime Rate Row */}
                  <tr>
                    <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Crime Rate
                    </td>
                    {selectedProperties.map((property) => (
                      <td 
                        key={property.id} 
                        className={`px-4 py-4 whitespace-nowrap text-sm ${
                          getBestProperty('crimeRate', false) === property.id
                            ? 'text-green-600 font-semibold'
                            : 'text-gray-900'
                        }`}
                      >
                        {['Very Low', 'Low', 'Medium', 'High', 'Very High'][property.crimeRate-1]}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
              <h3 className="font-semibold text-blue-900 mb-2">Analysis Summary</h3>
              <p className="text-blue-800 text-sm">
                {selectedProperties.length === 1 
                  ? "Add more properties to see a detailed comparison analysis."
                  : selectedProperties.length > 1 
                    ? `The ${selectedProperties.find(p => p.id === getBestProperty('predictedPrice', false))?.location} 
                       property offers the best value at 
                       ${formatCurrency(selectedProperties.find(p => p.id === getBestProperty('predictedPrice', false))?.predictedPrice || 0)}, 
                       while the ${selectedProperties.find(p => p.id === getBestProperty('schoolProximity'))?.location} 
                       property has the best school proximity. Consider your priorities when making a decision.`
                    : ""}
              </p>
            </div>
          </div>
        )}
        
        {/* CTA Section */}
        <div className="text-center mt-8">
          <Link
            to="/"
            className="inline-flex items-center px-6 py-3 border border-transparent text-lg font-medium rounded-md text-white bg-gradient-to-r from-blue-800 to-teal-600 hover:from-blue-700 hover:to-teal-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 shadow-md transition-all duration-300"
          >
            Make Another Prediction
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CompareProperties;