import Hero from '../components/Hero';
import PredictionForm from '../components/PredictionForm';
import { Building, Repeat, TrendingUp, Award } from 'lucide-react';

const Home = () => {
  return (
    <div>
      <Hero />
      
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Predict Your Property's Value in Kolkata
            </h2>
            <p className="text-xl text-gray-600">
              Our advanced AI model considers multiple factors to give you 
              the most accurate property valuation in the Kolkata real estate market.
            </p>
          </div>
          
          <PredictionForm />
        </div>
      </section>
      
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Use KolkataHomes?
            </h2>
            <p className="text-xl text-gray-600">
              We combine data science with deep local expertise to provide
              the most accurate property valuations in Kolkata.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gray-50 rounded-lg p-6 text-center hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-blue-100 text-blue-900 rounded-full">
                <Building size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Local Market Expertise</h3>
              <p className="text-gray-600">
                Our models are specifically trained on Kolkata's unique property market data 
                for unmatched local accuracy.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 text-center hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-teal-100 text-teal-900 rounded-full">
                <Repeat size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Comprehensive Analysis</h3>
              <p className="text-gray-600">
                We consider over 20 different factors including location, amenities, and 
                neighborhood statistics.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 text-center hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-amber-100 text-amber-900 rounded-full">
                <TrendingUp size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">ROI Predictions</h3>
              <p className="text-gray-600">
                Get accurate ROI projections based on historical trends and 
                upcoming developments in your area.
              </p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-6 text-center hover:shadow-md transition-all duration-300 transform hover:-translate-y-1">
              <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-purple-100 text-purple-900 rounded-full">
                <Award size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2 text-gray-900">Trusted by Professionals</h3>
              <p className="text-gray-600">
                Real estate agents, investors, and homeowners across Kolkata trust 
                our accurate predictions.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 bg-gradient-to-r from-blue-900 to-teal-800 text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="md:w-1/2">
                <h2 className="text-3xl font-bold mb-4">
                  Ready to discover your property's value?
                </h2>
                <p className="text-xl opacity-90 mb-6">
                  Get started with a free prediction today and make informed 
                  real estate decisions in Kolkata's dynamic market.
                </p>
                <a
                  href="#prediction-form"
                  className="inline-block px-6 py-3 bg-white text-blue-900 font-medium rounded-lg hover:bg-opacity-90 transition-colors"
                >
                  Make a Prediction
                </a>
              </div>
              
              <div className="md:w-1/2 mt-8 md:mt-0">
                <div className="bg-white bg-opacity-10 p-6 rounded-lg border border-white border-opacity-20 backdrop-blur-sm">
                  <h3 className="text-xl font-semibold mb-4">Trusted by Kolkata's Top Agencies</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-white bg-opacity-20 h-12 rounded flex items-center justify-center">
                      <span className="font-medium">Realty Solutions</span>
                    </div>
                    <div className="bg-white bg-opacity-20 h-12 rounded flex items-center justify-center">
                      <span className="font-medium">Bengal Homes</span>
                    </div>
                    <div className="bg-white bg-opacity-20 h-12 rounded flex items-center justify-center">
                      <span className="font-medium">Kolkata Estates</span>
                    </div>
                    <div className="bg-white bg-opacity-20 h-12 rounded flex items-center justify-center">
                      <span className="font-medium">City Property</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;