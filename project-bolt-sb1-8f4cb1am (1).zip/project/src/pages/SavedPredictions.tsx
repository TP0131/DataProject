import { useState, useEffect } from 'react';
import { ArrowLeft, Trash2, RefreshCw, ExternalLink } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Property } from '../types';
import { formatCurrency } from '../utils/formatters';

const SavedPredictions = () => {
  const [savedProperties, setSavedProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  
  useEffect(() => {
    // Load saved predictions
    const savedPredictionsJson = localStorage.getItem('savedPredictions');
    if (savedPredictionsJson) {
      const parsedProperties = JSON.parse(savedPredictionsJson);
      setSavedProperties(parsedProperties);
    }
    setLoading(false);
  }, []);
  
  const handleDeleteProperty = (propertyId: string) => {
    if (confirm('Are you sure you want to delete this saved prediction?')) {
      const updatedProperties = savedProperties.filter(p => p.id !== propertyId);
      setSavedProperties(updatedProperties);
      localStorage.setItem('savedPredictions', JSON.stringify(updatedProperties));
    }
  };
  
  const handleClearAll = () => {
    if (confirm('Are you sure you want to delete all saved predictions?')) {
      setSavedProperties([]);
      localStorage.removeItem('savedPredictions');
    }
  };
  
  const handleCompareSelected = (property: Property) => {
    // Save property and navigate to compare page
    localStorage.setItem('currentPrediction', JSON.stringify(property));
    navigate('/compare');
  };

  return (
    <div className="bg-gray-50 min-h-screen py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center text-blue-900 hover:text-blue-700">
            <ArrowLeft size={20} className="mr-2" />
            <span>Back to Home</span>
          </Link>
          
          <div className="flex justify-between items-center mt-4">
            <h1 className="text-3xl font-bold text-gray-900">Saved Predictions</h1>
            
            {savedProperties.length > 0 && (
              <button
                onClick={handleClearAll}
                className="inline-flex items-center px-4 py-2 border border-red-300 text-red-700 bg-white rounded-md hover:bg-red-50"
              >
                <Trash2 size={16} className="mr-2" />
                Clear All
              </button>
            )}
          </div>
          
          <p className="text-gray-600 mt-2">
            View and manage your saved property predictions.
          </p>
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center py-20">
            <RefreshCw size={24} className="animate-spin text-blue-900 mr-3" />
            <span>Loading saved predictions...</span>
          </div>
        ) : savedProperties.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <div className="text-gray-500 mb-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
                <RefreshCw size={24} className="text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold mb-2">No Saved Predictions</h2>
              <p>You haven't saved any property predictions yet.</p>
            </div>
            
            <Link
              to="/"
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gradient-to-r from-blue-800 to-teal-600 hover:from-blue-700 hover:to-teal-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 shadow-md transition-all duration-300"
            >
              Make Your First Prediction
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedProperties.map((property) => (
              <div 
                key={property.id}
                className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow duration-300"
              >
                <div className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h2 className="text-xl font-bold text-blue-900">{property.location}</h2>
                      <p className="text-sm text-gray-500">
                        Saved on {new Date(property.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    
                    <button
                      onClick={() => handleDeleteProperty(property.id)}
                      className="text-gray-400 hover:text-red-500"
                      aria-label="Delete property"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                  
                  <div className="mb-4">
                    <div className="text-2xl font-bold text-blue-900 mb-1">
                      {formatCurrency(property.predictedPrice)}
                    </div>
                    <div className="text-sm text-gray-500">
                      {formatCurrency(property.predictedPrice / property.size)} per sq.ft
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-sm text-gray-500">Size</div>
                      <div className="font-semibold">{property.size} sq.ft</div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-sm text-gray-500">Rooms</div>
                      <div className="font-semibold">{property.rooms} BR / {property.bathrooms} Bath</div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-sm text-gray-500">Year Built</div>
                      <div className="font-semibold">{property.yearBuilt}</div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="text-sm text-gray-500">ROI</div>
                      <div className="font-semibold">{property.roi}%</div>
                    </div>
                  </div>
                  
                  <div className="flex space-x-3">
                    <button
                      onClick={() => handleCompareSelected(property)}
                      className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-900 hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      <ExternalLink size={16} className="mr-2" />
                      Compare
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default SavedPredictions;