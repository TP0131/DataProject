export const formatCurrency = (amount: number): string => {
  // Format as Indian Rupees (₹)
  if (amount >= 10000000) {
    // Convert to crores (1 crore = 10 million)
    return `₹${(amount / 10000000).toFixed(2)} Cr`;
  } else if (amount >= 100000) {
    // Convert to lakhs (1 lakh = 100,000)
    return `₹${(amount / 100000).toFixed(2)} L`;
  } else {
    // Format with commas (Indian numbering system)
    return `₹${amount.toLocaleString('en-IN')}`;
  }
};