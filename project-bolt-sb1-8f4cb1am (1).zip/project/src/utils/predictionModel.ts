import { Property } from '../types';

// Base prices for different neighborhoods in Kolkata (in INR)
const locationBasePrices: Record<string, number> = {
  'Salt Lake': 8500000,
  'New Town': 7800000,
  'Ballygunge': 12000000,
  'Alipore': 15000000,
  'Rajarhat': 6500000,
  'Behala': 5500000,
  'Tollygunge': 7000000,
  'Lake Gardens': 9000000,
  'Jadavpur': 6200000,
  'Garia': 5800000,
  'Dum Dum': 5000000,
  'Barasat': 4500000,
  'Park Street': 13000000,
  'Bhowanipore': 10000000,
  'Howrah': 5200000,
  'Sealdah': 6000000,
  'Gariahat': 8000000,
  'Kasba': 6500000,
  'Barrackpore': 4800000,
  'Konnagar': 4200000,
  // Default for any other location
  'default': 6000000
};

// Calculate ROI based on location and other factors
const calculateROI = (property: Property): number => {
  // Base ROI for Kolkata is around 4-7%
  let baseROI = 5;
  
  // Premium locations have higher ROI
  const premiumLocations = ['Ballygunge', 'Alipore', 'Park Street', 'Salt Lake', 'New Town'];
  if (premiumLocations.includes(property.location)) {
    baseROI += 1.5;
  }
  
  // Newer properties tend to have better ROI
  const currentYear = new Date().getFullYear();
  if (property.yearBuilt >= currentYear - 5) {
    baseROI += 0.8;
  } else if (property.yearBuilt <= currentYear - 20) {
    baseROI -= 0.5;
  }
  
  // Good school proximity improves ROI
  if (property.schoolProximity >= 4) {
    baseROI += 0.7;
  }
  
  // High crime rate decreases ROI
  if (property.crimeRate >= 4) {
    baseROI -= 1;
  }
  
  // Add some randomness for realistic variation
  baseROI += (Math.random() * 0.6) - 0.3;
  
  // Round to one decimal place
  return parseFloat(baseROI.toFixed(1));
};

// Main prediction function
export const predictHousePrice = async (property: Property): Promise<Property> => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Get base price for location
  const basePrice = locationBasePrices[property.location] || locationBasePrices.default;
  
  // Calculate price per square foot (varies by location)
  let pricePerSqFt = basePrice / 1000; // Default price per sq ft
  
  // Calculate size factor (larger properties may have slightly lower per sq ft price)
  const sizeFactor = property.size <= 800 ? 1.1 : 
                     property.size <= 1200 ? 1 : 
                     property.size <= 2000 ? 0.95 : 0.9;
  
  // Calculate room factor
  const roomFactor = 1 + ((property.rooms - 2) * 0.1); // +10% per room above 2
  
  // Calculate bathroom factor
  const bathroomFactor = 1 + ((property.bathrooms - 1) * 0.07); // +7% per bathroom above 1
  
  // Calculate age factor (newer properties command premium)
  const currentYear = new Date().getFullYear();
  const age = currentYear - property.yearBuilt;
  const ageFactor = age <= 2 ? 1.2 : 
                   age <= 5 ? 1.15 : 
                   age <= 10 ? 1.1 : 
                   age <= 15 ? 1.05 : 
                   age <= 25 ? 1 : 
                   age <= 40 ? 0.9 : 0.8;
  
  // School proximity factor
  const schoolFactor = 1 + ((property.schoolProximity - 3) * 0.05);
  
  // Park proximity factor
  const parkFactor = 1 + ((property.parkProximity - 3) * 0.03);
  
  // Crime rate factor (lower is better)
  const crimeFactor = 1 - ((property.crimeRate - 2) * 0.04);
  
  // Calculate predicted price
  let predictedPrice = pricePerSqFt * property.size * sizeFactor * roomFactor * 
                       bathroomFactor * ageFactor * schoolFactor * parkFactor * crimeFactor;
  
  // Add some randomness (±8%) for realistic variation
  const randomFactor = 1 + ((Math.random() * 0.16) - 0.08);
  predictedPrice *= randomFactor;
  
  // Calculate ROI
  const roi = calculateROI(property);
  
  // Calculate price range (±10-15% of predicted price)
  const rangeFactor = 0.1 + (Math.random() * 0.05);
  const minPrice = predictedPrice * (1 - rangeFactor);
  const maxPrice = predictedPrice * (1 + rangeFactor);
  
  // Round to nearest 10000
  predictedPrice = Math.round(predictedPrice / 10000) * 10000;
  
  // Return updated property with prediction results
  return {
    ...property,
    predictedPrice,
    roi,
    priceRange: {
      min: Math.round(minPrice / 10000) * 10000,
      max: Math.round(maxPrice / 10000) * 10000
    }
  };
};